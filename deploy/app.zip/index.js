import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { DefaultAzureCredential } from '@azure/identity';
import OpenAI, { toFile } from 'openai';
import dotenv from 'dotenv';
import { initCosmosDb, isDbAvailable, saveGeneration, getGenerations, getGeneration, deleteGeneration } from './db.js';
import { initBlobStorage, isStorageAvailable, uploadMedia, deleteMedia } from './storage.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Azure OpenAI configuration
const AZURE_OPENAI_ENDPOINT = process.env.AZURE_OPENAI_ENDPOINT;
const AZURE_FOUNDRY_ENDPOINT = process.env.AZURE_FOUNDRY_ENDPOINT || process.env.AZURE_OPENAI_ENDPOINT;
const SORA_MODEL = process.env.SORA_MODEL_DEPLOYMENT || 'sora-2';
const IMAGE_MODEL = process.env.IMAGE_MODEL_DEPLOYMENT || 'gpt-image-1.5';
const AZURE_OPENAI_API_KEY = process.env.AZURE_OPENAI_API_KEY;

// Initialize Azure credential
const credential = new DefaultAzureCredential();

// Helper function to get Azure AD token
async function getAzureToken() {
  const tokenResponse = await credential.getToken('https://cognitiveservices.azure.com/.default');
  return tokenResponse.token;
}

// Create OpenAI client with API key
const openai = new OpenAI({
  baseURL: `${AZURE_OPENAI_ENDPOINT}/openai/v1/`,
  apiKey: AZURE_OPENAI_API_KEY ?? await getAzureToken()
});

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Initialize storage backends (non-blocking)
(async () => {
  await initCosmosDb();
  await initBlobStorage();
})();

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    endpoints: {
      openai: AZURE_OPENAI_ENDPOINT,
      foundry: AZURE_FOUNDRY_ENDPOINT
    },
    models: {
      video: SORA_MODEL,
      image: IMAGE_MODEL
    },
    storage: {
      cosmosDb: isDbAvailable(),
      blobStorage: isStorageAvailable()
    }
  });
});

// Helper: convert a base64 or data-URL string to a File object for the edit API
async function base64ToFile(input, filename = 'image.png') {
  const base64Data = input.startsWith('data:') ? input.split(',')[1] : input;
  const imageBuffer = Buffer.from(base64Data, 'base64');
  return toFile(imageBuffer, filename, { type: 'image/png' });
}

// Generate image endpoint (Image API)
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, size = 'auto', quality = 'auto', inputImages } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const imageCount = Array.isArray(inputImages) ? inputImages.length : 0;
    console.log(`Generating image with prompt: "${prompt}"`);
    console.log(`Image size: ${size}, Model: ${IMAGE_MODEL}, Reference images: ${imageCount}`);

    let result;

    if (inputImages && inputImages.length > 0) {
      // Use images.edit when reference images are provided
      // Convert all images to File objects
      const imageFiles = await Promise.all(
        inputImages.map((img, i) => base64ToFile(img, `reference-${i}.png`))
      );

      result = await openai.images.edit({
        model: IMAGE_MODEL,
        image: imageFiles.length === 1 ? imageFiles[0] : imageFiles,
        prompt: prompt,
        ...(size !== 'auto' && { size }),
        quality,
        input_fidelity: 'high',
      });
    } else {
      // Use images.generate for text-only prompts
      result = await openai.images.generate({
        model: IMAGE_MODEL,
        prompt: prompt,
        ...(size !== 'auto' && { size }),
        quality,
        n: 1,
      });
    }

    console.log('Image generation response received');

    const imageBase64 = result.data?.[0]?.b64_json;
    const revisedPrompt = result.data?.[0]?.revised_prompt;

    // Auto-save to history (non-blocking)
    let savedId = null;
    if (isDbAvailable() && imageBase64) {
      try {
        let mediaUrl = null;
        if (isStorageAvailable()) {
          mediaUrl = await uploadMedia(imageBase64, 'png', 'image/png');
        }
        const saved = await saveGeneration({
          type: 'image',
          prompt,
          settings: { imageSize: size, quality },
          groundingImageCount: imageCount,
          result: { mediaUrl, revisedPrompt: revisedPrompt },
        });
        savedId = saved.id;
        console.log('Generation saved to history:', savedId);
      } catch (saveErr) {
        console.error('Failed to save generation:', saveErr.message);
      }
    }

    res.json({
      status: 'completed',
      type: 'image',
      data: imageBase64,
      revised_prompt: revisedPrompt,
      savedId,
      _raw: result
    });
  } catch (error) {
    console.error('Error generating image:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Edit/refine image endpoint (Image API - images.edit)
app.post('/api/refine-image', async (req, res) => {
  try {
    const { prompt, previousImage, size = 'auto', quality = 'auto' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (!previousImage) {
      return res.status(400).json({ error: 'Previous image data is required for refinement' });
    }

    console.log(`Refining image with prompt: "${prompt}"`);

    // Convert the previous image to a file
    const sourceFile = await base64ToFile(previousImage, 'source.png');

    const result = await openai.images.edit({
      model: IMAGE_MODEL,
      image: sourceFile,
      prompt: prompt,
      ...(size !== 'auto' && { size }),
      quality,
      input_fidelity: "high"
    });

    console.log('Image refinement response received');

    const refinedBase64 = result.data?.[0]?.b64_json;
    const refinedPrompt = result.data?.[0]?.revised_prompt;

    // Auto-save refinement to history (non-blocking)
    let savedId = null;
    if (isDbAvailable() && refinedBase64) {
      try {
        let mediaUrl = null;
        if (isStorageAvailable()) {
          mediaUrl = await uploadMedia(refinedBase64, 'png', 'image/png');
        }
        const saved = await saveGeneration({
          type: 'image',
          prompt: `[Refined] ${prompt}`,
          settings: { imageSize: size, quality },
          groundingImageCount: 1,
          result: { mediaUrl, revisedPrompt: refinedPrompt },
        });
        savedId = saved.id;
        console.log('Refinement saved to history:', savedId);
      } catch (saveErr) {
        console.error('Failed to save refinement:', saveErr.message);
      }
    }

    res.json({
      status: 'completed',
      type: 'image',
      data: refinedBase64,
      revised_prompt: refinedPrompt,
      savedId,
      _raw: result
    });
  } catch (error) {
    console.error('Error refining image:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Generate video endpoint
app.post('/api/generate-video', async (req, res) => {
  try {
    const { prompt, size = '720x1280', seconds = '4' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    console.log(`Generating video with prompt: "${prompt}"`);

    // Call Azure OpenAI Sora API
    const response = await fetch(`${AZURE_OPENAI_ENDPOINT}/openai/v1/videos`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': AZURE_OPENAI_API_KEY
      },
      body: JSON.stringify({
        prompt,
        size,
        seconds,
        model: SORA_MODEL
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Azure OpenAI Error:', errorText);
      return res.status(response.status).json({ 
        error: 'Failed to generate video', 
        details: errorText 
      });
    }

    const data = await response.json();
    console.log('Video generation response:', JSON.stringify(data, null, 2));

    // Return full response with any nested data flattened for easier access
    res.json({
      ...data,
      _raw: data // Keep raw response for debugging
    });
  } catch (error) {
    console.error('Error generating video:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Check video status endpoint
app.get('/api/video-status/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const response = await fetch(`${AZURE_OPENAI_ENDPOINT}/openai/v1/videos/${id}`, {
      method: 'GET',
      headers: {
        'api-key': AZURE_OPENAI_API_KEY
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      return res.status(response.status).json({ 
        error: 'Failed to get video status', 
        details: errorText 
      });
    }

    const data = await response.json();
    console.log('Video status response:', JSON.stringify(data, null, 2));
    
    // If completed, try to get the video content/generations
    if (data.status === 'completed' || data.status === 'succeeded') {
      // Try fetching generations/content endpoint
      try {
        const generationsResponse = await fetch(`${AZURE_OPENAI_ENDPOINT}/openai/v1/videos/${id}/content`, {
          method: 'GET',
          headers: {
            'api-key': AZURE_OPENAI_API_KEY
          }
        });
        
        if (generationsResponse.ok) {
          const contentType = generationsResponse.headers.get('content-type');
          
          if (contentType && contentType.includes('application/json')) {
            const generationsData = await generationsResponse.json();
            console.log('Video content response:', JSON.stringify(generationsData, null, 2));
            return res.json({ ...data, ...generationsData, _contentData: generationsData });
          } else {
            // It's the actual video binary - return a URL to our proxy endpoint
            console.log('Video content is binary, content-type:', contentType);
            return res.json({ 
              ...data, 
              video_url: `/api/video-content/${id}`,
              _videoContentAvailable: true 
            });
          }
        }
      } catch (contentErr) {
        console.log('Could not fetch content endpoint:', contentErr.message);
      }
    }
    
    res.json(data);
  } catch (error) {
    console.error('Error checking video status:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Get video content directly
app.get('/api/video-content/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const response = await fetch(`${AZURE_OPENAI_ENDPOINT}/openai/v1/videos/${id}/content`, {
      method: 'GET',
      headers: {
        'api-key': AZURE_OPENAI_API_KEY
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      return res.status(response.status).json({ 
        error: 'Failed to get video content', 
        details: errorText 
      });
    }

    const contentType = response.headers.get('content-type') || 'video/mp4';
    const contentLength = response.headers.get('content-length');
    
    res.setHeader('Content-Type', contentType);
    if (contentLength) {
      res.setHeader('Content-Length', contentLength);
    }
    
    const buffer = await response.arrayBuffer();
    res.send(Buffer.from(buffer));
  } catch (error) {
    console.error('Error getting video content:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Download video endpoint (proxy to avoid CORS issues)
app.get('/api/download-video', async (req, res) => {
  try {
    const { url } = req.query;
    
    if (!url) {
      return res.status(400).json({ error: 'Video URL is required' });
    }

    console.log('Downloading video from:', url);

    // First try without auth (for SAS URLs or public URLs)
    let response = await fetch(url);
    
    // If unauthorized, try with API key
    if (response.status === 401 || response.status === 403) {
      console.log('Trying with API key...');
      response = await fetch(url, {
        headers: {
          'api-key': AZURE_OPENAI_API_KEY
        }
      });
    }

    if (!response.ok) {
      console.error('Download failed with status:', response.status);
      const errorText = await response.text();
      console.error('Error details:', errorText);
      return res.status(response.status).json({ error: 'Failed to download video', details: errorText });
    }

    // Set appropriate headers for video download
    const contentType = response.headers.get('content-type') || 'video/mp4';
    const contentLength = response.headers.get('content-length');
    
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'attachment; filename="sora-generated-video.mp4"');
    if (contentLength) {
      res.setHeader('Content-Length', contentLength);
    }

    // Stream the response
    const buffer = await response.arrayBuffer();
    console.log('Video downloaded, size:', buffer.byteLength, 'bytes');
    res.send(Buffer.from(buffer));
  } catch (error) {
    console.error('Error downloading video:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Direct video content endpoint (for base64 or embedded video data)
app.post('/api/save-video', async (req, res) => {
  try {
    const { videoData, format = 'mp4' } = req.body;
    
    if (!videoData) {
      return res.status(400).json({ error: 'Video data is required' });
    }

    // Handle base64 encoded video
    const buffer = Buffer.from(videoData, 'base64');
    
    res.setHeader('Content-Type', `video/${format}`);
    res.setHeader('Content-Disposition', `attachment; filename="sora-generated-video.${format}"`);
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (error) {
    console.error('Error saving video:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      message: error.message 
    });
  }
});

// Save a completed video generation to history
app.post('/api/save-generation', async (req, res) => {
  try {
    if (!isDbAvailable()) {
      return res.status(503).json({ error: 'History storage not available' });
    }

    const { type, prompt, settings, mediaData, mediaExtension, mediaContentType } = req.body;

    let mediaUrl = null;
    if (isStorageAvailable() && mediaData) {
      mediaUrl = await uploadMedia(mediaData, mediaExtension || 'mp4', mediaContentType || 'video/mp4');
    }

    const saved = await saveGeneration({
      type: type || 'video',
      prompt,
      settings: settings || {},
      result: { mediaUrl },
    });

    res.json({ id: saved.id, mediaUrl });
  } catch (error) {
    console.error('Error saving generation:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// ──────────────── History API ────────────────

// List generations
app.get('/api/generations', async (req, res) => {
  try {
    if (!isDbAvailable()) {
      return res.json({ generations: [], message: 'History storage not available' });
    }

    const limit = parseInt(req.query.limit) || 50;
    const continuationToken = req.query.continuationToken || undefined;
    const result = await getGenerations('default', limit, continuationToken);
    res.json(result);
  } catch (error) {
    console.error('Error fetching generations:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Get single generation
app.get('/api/generations/:id', async (req, res) => {
  try {
    if (!isDbAvailable()) {
      return res.status(503).json({ error: 'History storage not available' });
    }

    const item = await getGeneration(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Generation not found' });
    }
    res.json(item);
  } catch (error) {
    console.error('Error fetching generation:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Delete generation
app.delete('/api/generations/:id', async (req, res) => {
  try {
    if (!isDbAvailable()) {
      return res.status(503).json({ error: 'History storage not available' });
    }

    // Get the item first to delete associated media
    const item = await getGeneration(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Generation not found' });
    }

    // Delete media from blob storage
    if (item.result?.mediaUrl) {
      await deleteMedia(item.result.mediaUrl);
    }

    // Delete from Cosmos DB
    await deleteGeneration(req.params.id);
    res.json({ message: 'Deleted successfully' });
  } catch (error) {
    console.error('Error deleting generation:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Serve static files from the React app in production
if (process.env.NODE_ENV === 'production') {
  const fs = await import('fs');
  
  // Try multiple possible paths for client dist
  const possiblePaths = [
    path.join(__dirname, 'client', 'dist'),        // Flat structure: index.js and client/ at same level
    path.join(__dirname, '..', 'client', 'dist'),  // Nested: server/index.js with client/ at parent
    path.join(process.cwd(), 'client', 'dist'),    // From working directory
  ];
  
  let clientDistPath = possiblePaths[0];
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      clientDistPath = p;
      console.log(`✅ Found client dist at: ${p}`);
      break;
    } else {
      console.log(`❌ Client dist not found at: ${p}`);
    }
  }
  
  app.use(express.static(clientDistPath));
  
  // Handle React routing - serve index.html for all non-API routes
  app.get('*', (req, res) => {
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
}

const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📍 Azure OpenAI Endpoint: ${AZURE_OPENAI_ENDPOINT}`);
  console.log(`📍 Azure Foundry Endpoint: ${AZURE_FOUNDRY_ENDPOINT}`);
  console.log(`🎬 Sora Model: ${SORA_MODEL}`);
  console.log(`🖼️  Image Model: ${IMAGE_MODEL}`);
});

// Graceful shutdown for Azure Container Apps
const gracefulShutdown = (signal) => {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  server.close(() => {
    console.log('HTTP server closed.');
    process.exit(0);
  });

  // Force close after 10 seconds
  setTimeout(() => {
    console.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
